# ATS / AI-readability QA checklist — run before delivering

Run the two gates and read both reports, then confirm each item by eye on the rendered page images:

```bash
python3 scripts/lint_cv.py cv <cv.md> --profile <profile>/profile.md --fit <app dir>/fit.md
python3 scripts/check_pdf.py <file.pdf> --keywords "kw1;kw2;..."
```

`lint_cv.py` records its result in `<app dir>/gates.json`; a FAIL there blocks the submission
(`learn.py log-outcome --status applied` refuses). Fix every FAIL by rewriting, never by deleting
the check's trigger word and leaving a broken sentence.

## Structure
- [ ] Single column, no tables for body content (the builder only uses a
      borderless 2-cell row for role-title/date lines, which extracts in order).
- [ ] Standard section names in this order: Professional Summary · Work Experience · (Open
      Source, or a programme-statement section ONLY for an accelerator or investor programme that
      asks for one) · Education · Skills (one plain line) · Languages (optional). No skills grid
      above the work history. No "Why <Company>" section on an employment CV.
- [ ] Contact block on page 1 top: name, headline, email, phone, city+country,
      LinkedIn, website — all as real text (no icons-only, no header/footer
      objects; parsers skip headers/footers).
- [ ] Every role line reads: Title · Company · Location · dates as MM/YYYY – MM/YYYY
      or YYYY – YYYY or "Present". Same format throughout.
- [ ] Strictly reverse-chronological by start date (lint_cv.py checks), no unexplained gaps
      > 1 month. Overlaps framed per the profile's framing policy.
- [ ] ≤ 2 pages. Page 1 stands alone.
- [ ] **One date format** throughout (lint_cv.py checks).
- [ ] **No orphaned bullet lines** — every wrapped line keeps the hanging indent (check_pdf.py
      checks). Look at the `--png` page images too.
- [ ] Each role line fits on one line.
- [ ] Every link shows its URL as text (`example.com`-style), never a linked title.

## Design (must stay invisible to a parser)
- [ ] Decoration is drawn shapes only (band, dots, timeline rule, rings, hairlines); no text in
      graphics, no icons, no skill bars, no stat tiles.
- [ ] Extraction starts name → headline → contact → status; the photo (if any) carries no text.
- [ ] The only footer text is `Name, Headline · n / total` (designed) or `name · page` on page 2+
      (classic), and it extracts LAST on its page.
- [ ] Photo only for a market that expects one (`designed-template.md` §1); no DOB, marital
      status, religion or ID number.
- [ ] File ≤ 1 MB (a designed CV with photo is ~90 KB); every font embedded, no Type3
      (`check_pdf.py` checks both).

## Text & fonts
- [ ] Real embedded TrueType text (pdffonts shows emb=yes); no text-as-image.
- [ ] No text in white/tiny/hidden; no keyword blocks disguised as design.
- [ ] Bullets are real characters ("•") rendered by the builder, not glyph
      fonts (Wingdings) that parse as garbage.
- [ ] Diacritics render (e.g. Zürich, Kraków, São Paulo) — the builder embeds a Unicode font; if the
      keyword check shows "Kraków" as "Krak?w", the font fallback failed — fix, don't ship.
- [ ] Hyphens/dashes: en dash between dates is fine; avoid exotic symbols.

## Keywords
- [ ] Every must-have keyword from the JD appears in a bullet where it is true, and in the Skills
      line; acronym and long form on first use.
- [ ] Target job title appears verbatim in the headline (or first in the summary's opening sentence — playbook §3 Rung 1).
- [ ] Years of experience stated, using the profile's own figure.
- [ ] check_pdf.py reports 0 missing must-have keywords.

## Extraction test (what the ATS actually sees)
- [ ] `pdftotext -layout` output reads top-to-bottom, sections in order,
      role line and dates on the same line, no interleaving from columns.
- [ ] First 300 characters contain: name, headline, email, phone.

## Human gate
- [ ] Headline mirrors the target title.
- [ ] First bullet of the first role answers the JD's #1 requirement.
- [ ] Bold lead-ins on at most half the bullets per role, on the ones that answer a `critical`
      row of fit.md.
- [ ] No claim outside profile/profile.md (lint_cv.py `--profile` fact gate is green).
- [ ] No first person, no gap named, no banned phrase (lint_cv.py is green).
- [ ] Every bullet in the three most recent roles answers a row of fit.md's `## Bullet plan`.
- [ ] Headline = the posting's title + one short differentiator; no "-level" phrasing anywhere.
- [ ] Titles, employers and dates match the user's LinkedIn.
- [ ] Contact set matches the location decision; DOB absent unless required.
