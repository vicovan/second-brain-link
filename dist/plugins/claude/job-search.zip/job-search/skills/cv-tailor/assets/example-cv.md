---
type: cv
title: Jane Doe — VP Engineering
tags: [jobsearch, cv, example]
name: Jane Doe
headline: "VP Engineering · data platforms under regulatory load"
output_basename: Jane_Doe_CV_Northwind_Data
company: Northwind Data
role: VP Engineering
target_type: Series C data platform, hybrid
contact_set: EU set — the role is EU-remote and she needs no sponsorship there
email: jane.doe@example.com
phone: "+00 000 000 000"
location: Lisbon, Portugal
status: Portuguese / EU citizen
market: PT
keywords: [VP Engineering, data platform, streaming, multi-tenant SaaS]
links:
  - text: linkedin.com/in/janedoe
    url: https://www.linkedin.com/in/janedoe/
---

<!-- A fictional example. Every person, company and number here is invented — it exists to show the
     shape of the format and the register of the writing, never to be copied as fact.
     What to notice: the headline is the posting's title plus one short differentiator; the summary
     is three sentences of uneven length; bullets open with a verb, say what changed for whom before
     how; at most one bullet per role uses a "Label:" opener; one date format throughout; the
     current employed role is on top and the open-source work sits in its own small section; the
     summary says who she is in plain sentences, with no bolded title label; skills are one plain
     line at the end, never a grid at the top. The design is not in the frontmatter: the
     user's CV design settings decide it (template, palette, photo). Only `market:` is written —
     the photo policy reads it — and `keywords:` for the PDF metadata. -->

## Professional Summary
<!-- blocks: prose -->

Engineering leader with 14 years in data platforms, the last five running the group behind a
multi-tenant analytics product for 400 enterprise customers. Rebuilt its ingestion as a streaming
system with no maintenance window, cutting data latency from 6 hours to under 4 minutes. Hires
managers, grows teams across time zones, and still reviews code.

## Work Experience
<!-- blocks: mixed -->

### Director of Engineering | Meridian Analytics · Enterprise Analytics Platform
*03/2021 – Present*
Remote from Portugal · US company (Boston) · Series C, 300 staff
<https://example.com>

*Leads the platform group of 23 engineers and two managers, reporting to the CTO.*

- Moved 400 enterprise customers from nightly batches to streaming data, cutting latency from
  6 hours to under 4 minutes with no maintenance window.
- Grew the platform group from 9 to 23 across three time zones and hired the two engineering
  managers who now run it.
- Put a data-quality score in front of all 400 customers, backed by lineage on every field and
  contract tests at each boundary.

### Staff Engineer | Northwind Systems · B2B Logistics SaaS
*06/2017 – 02/2021*
Lisbon, Portugal

- Led the move off a shared monolith database to per-service stores in 14 increments, with
  no customer-visible downtime.
- Wrote the incident practice still used across its 30 services.

### Backend Engineer | Globex Payments · Marketplace Payments
*09/2011 – 05/2017*
Lisbon, Portugal · acquired 2017

- Built the settlement service that carried 1.2 million transactions a month at acquisition.

## Open Source
<!-- blocks: mixed -->

Maintainer of streamcheck (MIT), [streamcheck.example.com](https://streamcheck.example.com), a
schema-contract test tool for Kafka topics.

- Used in production by teams at three companies; 40 contributors.

## Education
<!-- blocks: entries -->

- **MSc Computer Science** · University of Lisbon — 06/2011

## Skills
<!-- blocks: prose -->

Streaming architecture, event-driven systems, multi-tenant SaaS, data quality and lineage,
observability, incident practice, hiring and developing engineering managers, Python, Go, Kafka,
PostgreSQL, Kubernetes, AWS
