# Search method — how to run a sweep for anyone

**What to search for is not here.** Lanes, titles, geographies, the compensation floor and the hard
exclusions all live in the user's `profile/search-criteria.md`; the numbers live in
`profile/scoring.md`. This file is the procedure that turns those into a shortlist, and it is the
same procedure for every user.

If no profile is reachable, **stop and run onboarding**. Never guess a compensation floor, a
location or a target title — a shortlist built on invented criteria wastes the user's whole day.

## 1. Freshness and volume

Sweep the last **4–5 days** by default, widening from whatever `scout_state.py window` reports since
the last run. **Deliver only what clears the apply floor** (`scoring-rubric.md`), up to the
shortlist target `learn.py target` prints for the day's `daily-target:`. Widening
the *sources* to reach it is expected — another ATS board, a remote-flagged pass, a drill-down — but never widen the
*lanes* or lower the floor to reach a number: a padded list is how a week of applications goes out
to roles the candidate was never going to be shortlisted for. Say plainly how thin the day was.

## 2. Source order — market, then companies, then their own sites

1. **Discovery, per market** (`sources.md` Tier 0, `regional-sources.md`): LinkedIn's public
   search, the market's regional boards and recruiters, search engines — all limited to what was
   posted since the last run (`scout_state.py since-seconds`).
2. **The company registry** (Tier 1): every company discovery named, swept at its own careers
   board — the full list, the real posting date, the real apply link.
3. **The open ATS pool** and Y Combinator (Tier 1b, Tier 3) for US and EU tech.

Then `scout_state.py merge` collapses the same job seen on several sources into one row and marks
what is new since the last run, and `scout_state.py coverage` decides whether every market was
actually searched.

**Never conclude a market is empty from one source.** The open ATS boards cover US and EU tech
well and the Gulf hardly at all; a sweep that used only them once reported "zero" in a market with
hundreds of live roles. The coverage gate exists so that cannot happen silently: a market with no
in-lane rows from fewer than three sources is a failure to widen, not a result to report.

**Applyability comes after discovery, not instead of it.** A walled portal (Workday,
SuccessFactors) is surfaced with the portal named when criteria `walled: surface` — it is a role
the user applies to themselves, not a role to hide.

## 3. Exclude before you score

Apply the profile's hard exclusions **before** ranking, not as a penalty afterwards. Report the
count in one line; do not list them all.

**Do not rely on the title and the company name alone.** Any employer whose sector is unclear must
be read before it is ranked — a company posting as "Stealth" carries nothing incriminating in
either field, and only the body of the posting reveals what it actually does.

## 4. Read the real postings, but only the ones that survive

Score everything cheaply from title, company and location first. Take the top ~2× the shortlist target and fetch each
posting for what only the full text reveals: compensation, work-authorization wording, whether the
executive title means what it says, team size, funding. **Do not fetch all of them** — that is the
expensive step, and most candidates die on the title alone.

## 5. Applyability — establish it BEFORE anything reaches the list

**A job the user cannot apply to does not belong on the shortlist.** For every candidate that
survives scoring, establish how the application is submitted first:

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/skills/job-apply/scripts/detect_portal.py "<url>" --fetch
```

| Result | What to do |
|---|---|
| `linkedin` | **Resolve it first** — find the employer's own board (`site:job-boards.greenhouse.io "<company>"`, the company's `/careers` page). Classify the resolved URL, never the aggregator mirror. |
| `walled` | An account wall. Claude cannot create accounts. Criteria `walled: surface` (the default): keep and rank it, Apply column `⛔ <portal> — you apply`. `walled: drop`: list it under "excluded — account wall". |
| `fillable` | Keep, and **record the real apply URL in the report** so the apply step does not have to rediscover it. |
| `unknown` | Fetch the page and look for an account wall (*create an account · sign up to apply · register to apply · log in to apply · set a password*). Treat as walled only if found. |

The report's Apply column carries `✅ direct form (<ats>)` · `⛔ <portal> — you apply` · `✉️ email only` ·
`? unverified`. This costs a few fetches per run and saves the user discovering the wall themselves
after reading a role they liked. It is not optional.

## 6. Rank, cut, and be honest about the tail

Apply `scoring-rubric.md` with the user's weights. Rank, break ties on work mode, cut at the shortlist
target. If fewer clear the bar after the wider sweep, deliver fewer and say so.

## 7. Drill down when a company looks strong

The best-fitting role is often not the one that surfaced:

```bash
python3 <skill>/scripts/ats_fetch.py auto <company-slug> --filter "cto|vp|head of|chief|architect"
```

Append confirmed boards to `<state root>/companies.txt` so the pool compounds across runs.

## 8. Never invent

Every job in a report carries a real URL that was actually fetched. If a source returned nothing,
say so. Never fabricate a listing, a salary or a company, and never claim a skill, year or title the
profile does not contain in order to justify a match. A requirement the user does not meet is a red
flag to report, not a detail to gloss.
